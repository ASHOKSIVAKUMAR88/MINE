#include"stdio.h"
int add(int, int);
int sub(int, int);

int main() {
printf("add %d\n", add(4, 5));
printf("sub %d\n", sub(5, 4));
return 0;
}


#include<stdio.h>
#include"includes.h"
int main()
{
	main1();
	main2();
	main3();
	main4();
}

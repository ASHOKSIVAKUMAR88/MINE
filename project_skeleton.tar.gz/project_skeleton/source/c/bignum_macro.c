//#include"includes.h"
#include<stdio.h>
int main()
{

printf("big number is %d\n",10);
return 0;
}

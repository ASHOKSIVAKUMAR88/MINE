#include"includes.h"
int main6()
{
int res = big(10,2,3);
printf("big number is %d\n",res);
return 0;
}

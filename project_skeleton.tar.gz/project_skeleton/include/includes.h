#ifndef INCLUDES_H
	#define INCLUDES_H
#include<stdio.h>
#include<stdlib.h>
#include<sys/types.h>
#include<unistd.h>
#define MAXSIZE 5
#define big(a,b,c) (a>b?(a>c?a:c):(b>c?b:c))
#ifdef __cplusplus
extern "C"   
#endif 
int main1(void);
#ifdef __cplusplus
extern "C"   
#endif 
int main2(void);
#ifdef __cplusplus
extern "C"   
#endif 
int main3(void);
#ifdef __cplusplus
extern "C" 
#endif 
int main4(void);
#endif

/*
 *  BlueZ - Bluetooth protocol stack for Linux
 *
 *  Copyright (C) 2014  Google Inc.
 *
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdio.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <unistd.h>
#include <getopt.h>
#include <limits.h>
#include <errno.h>
#include <pthread.h>
#include <string.h>
#include <malloc.h>

#include <bluetooth/bluetooth.h>
#include <bluetooth/hci.h>
#include <bluetooth/hci_lib.h>
#include <bluetooth/l2cap.h>
#include "lib/uuid.h"

#include "monitor/mainloop.h"
#include "src/shared/util.h"
#include "src/shared/att.h"
#include "src/shared/queue.h"
#include "src/shared/gatt-db.h"
#include "src/shared/gatt-client.h"

#define ATT_CID 4

#define PRLOG(...) \
	printf(__VA_ARGS__); print_prompt();

#define COLOR_OFF	"\x1B[0m"
#define COLOR_RED	"\x1B[0;91m"
#define COLOR_GREEN	"\x1B[0;92m"
#define COLOR_YELLOW	"\x1B[0;93m"
#define COLOR_BLUE	"\x1B[0;94m"
#define COLOR_MAGENTA	"\x1B[0;95m"
#define COLOR_BOLDGRAY	"\x1B[1;30m"
#define COLOR_BOLDWHITE	"\x1B[1;37m"

static bool verbose = false;

struct client {
	int fd;
	struct gatt_db *db;
	struct bt_gatt_client *gatt;
};

void init (long int fd);

void *read_data(void *pfd);

	pthread_t tid;

static int l2cap_le_att_connect(bdaddr_t *src, bdaddr_t *dst, uint8_t dst_type,
									int sec)
{
	int sock;
	struct sockaddr_l2 srcaddr, dstaddr;
	struct bt_security btsec;

	if (verbose) {
		char srcaddr_str[18], dstaddr_str[18];

		ba2str(src, srcaddr_str);
		ba2str(dst, dstaddr_str);

		printf("btgatt-client: Opening L2CAP LE connection on ATT "
					"channel:\n\t src: %s\n\tdest: %s\n",
					srcaddr_str, dstaddr_str);
	}

	sock = socket(PF_BLUETOOTH, SOCK_SEQPACKET, BTPROTO_L2CAP);
	if (sock < 0) {
		perror("Failed to create L2CAP socket");
		return -1;
	}

	/* Set up source address */
	memset(&srcaddr, 0, sizeof(srcaddr));
	srcaddr.l2_family = AF_BLUETOOTH;
	srcaddr.l2_cid = htobs(ATT_CID);
	srcaddr.l2_bdaddr_type = 0;
	bacpy(&srcaddr.l2_bdaddr, src);

	if (bind(sock, (struct sockaddr *)&srcaddr, sizeof(srcaddr)) < 0) {
		perror("Failed to bind L2CAP socket");
		close(sock);
		return -1;
	}

	/* Set the security level */
	memset(&btsec, 0, sizeof(btsec));
	btsec.level = sec;
	if (setsockopt(sock, SOL_BLUETOOTH, BT_SECURITY, &btsec,
							sizeof(btsec)) != 0) {
		fprintf(stderr, "Failed to set L2CAP security level\n");
		close(sock);
		return -1;
	}

	/* Set up destination address */
	memset(&dstaddr, 0, sizeof(dstaddr));
	dstaddr.l2_family = AF_BLUETOOTH;
	dstaddr.l2_cid = htobs(ATT_CID);
	dstaddr.l2_bdaddr_type = dst_type;
	bacpy(&dstaddr.l2_bdaddr, dst);

	printf("Connecting to device...");
	fflush(stdout);

	if (connect(sock, (struct sockaddr *) &dstaddr, sizeof(dstaddr)) < 0) {
		perror(" Failed to connect");
		close(sock);
		return -1;
	}

	printf(" Done\n");

	return sock;
}


void *read_data(void *pfd)
{
	unsigned char rpdu[512];
	int len;
	int i;
	long int fd=(long int )pfd;
	while(1)
	{
	memset(rpdu,'\0',sizeof(rpdu));	
	len=read(fd,rpdu,512);	
	printf("no of bytes read=%d\n",len);	
	for(i=0;i<len;i++)
	printf("rpdu[%d]=0x%.2X\n",i,rpdu[i]);
	}
	return 0;
  }  
 
void init (long int fd)
{
  int error;
  
  error=pthread_create (&tid, NULL,read_data,(void *)fd);
  
if(error!=0)
printf("error in creation of thread \n");


}


int main(int argc, char *argv[])
{
	int sec = BT_SECURITY_LOW;
	uint8_t dst_type = BDADDR_LE_PUBLIC;
	bdaddr_t src_addr, dst_addr;
	int dev_id = -1;
	long int fd;
	unsigned char wpdu[512];
	
	int i,j=0,space=1,ret,size;
	char *name;
	char *temp;

name=(char *)malloc(sizeof(name));
temp=(char *)malloc(sizeof(temp);

	if(name == NULL)
	printf("malloc failed");
	if(temp == NULL)
	printf("malloc failed");

	if (str2ba(argv[2], &dst_addr) < 0) 
	{
		perror("Invalid remote address:\n");
		return EXIT_FAILURE;
	}
			
	if (dev_id == -1)
		bacpy(&src_addr, BDADDR_ANY);
	else if (hci_devba(dev_id, &src_addr) < 0) {
		perror("Adapter not available");
		return EXIT_FAILURE;
	}

	fd = l2cap_le_att_connect(&src_addr, &dst_addr, dst_type, sec);
	if (fd < 0)
		return EXIT_FAILURE;
		  
		init (fd);
	
	
while(1) {
  
   char c;
   
  
	printf("enter your command\n");
	ret=scanf("%[^\n]s",name);
	ret= scanf("%c", &c);
	printf("ret=%d\n",ret);
	memcpy(temp,name,strlen(name));
	space=1;
	j=0;
	
		while(*temp)
		{
			if(*temp==' ')
				++space;
		++temp;   
		}

   
	for(i=0;i<space;i++)
	{
	sscanf(name+j,"%x",(unsigned int *)&wpdu[i]);
	j+=3;
	}
	

	
	size=write(fd,wpdu,space);
	printf("\nWritting...");
	for(i=0;i<space;i++)
		printf(" 0x%.2x ",wpdu[i]);
	printf("\n");	
	printf("no of bytes written=%d\n\n	",size);
	
		
	printf("\n");
}

	pthread_join(tid,NULL);
	
return 0;
}
